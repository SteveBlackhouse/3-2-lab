from datetime import datetime
import random
import string


if __name__ == '__main__':
    user_id = 1
    current_date = datetime.now().strftime("%Y-%m-%d")
    csv = ''

    for i in range(2000):
        first_name = ''.join(random.choice(string.ascii_uppercase) for _ in range(10))
        last_name = ''.join(random.choice(string.ascii_uppercase) for _ in range(10))
        account_number = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(30))

        csv += str(user_id) + ',' + first_name + ',' + last_name + ',' + str(random.randrange(0, 100000)) + ','
        csv += account_number + ',' + current_date + ',' + str(random.randrange(1000, 100000)) + ',' + str(random.randint(6, 36))
        csv += ',' + str(random.randrange(1000, 100000)) + ',' + str(random.randint(6, 36)) + '\n'

        user_id += 1

    with open('../data.csv', 'w') as csv_file:
        csv_file.write(csv)
